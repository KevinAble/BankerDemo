﻿


.controller('AppCtrl', function($scope, $ionicModal, $timeout) {

    $scope.tranactions = [
        { account: "**126xx", date: "01/09/2014", description: "LOAN DISBURE", amount: "16,423.00" },
        { account: "**126xx", date: "01/07/2014 ", description: "LOAN DISBURSE", amount: "321.39" },
        { account: "**126xx", date: "01/06/2014 ", description: "INTEREST ACCRUAL", amount: "14.91" },
        { account: "**126xx", date: "01/02/2014 ", description: "PRIN PMT", amount: "19,200.00" },
        { account: "**126xx", date: "12/30/2013 ", description: "LOAN DISBURSE", amount: "121.19" },
        { account: "**126xx", date: "12/30/2013 ", description: "LOAN DISBURSE", amount: "2,300.00" },
        { account: "**126xx", date: "12/27/2013 ", description: "LOAN DISBURSE", amount: "13,431.26" },
        { account: "**126xx", date: "12/27/2013 ", description: "INTEREST ACCRUAL", amount: "155.34" },
        { account: "**126xx", date: "12/26/2013 ", description: "LOAN DISBURSE", amount: "927.33" }
    ];
});
